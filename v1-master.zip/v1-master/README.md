Pure CSS Framework

Web UI and layout design made with pure CSS. No Javascript requirements at all!

Super light weight, responsive and lightning fast! No JavaScript components to load so there is no wait time for hover menus, accordians, tabs or any other components of Pure CSS Framework (PCF).
Perfect for non-javascript programmers as well as skilled programmers. Use PCF for quick wire frame designs or full out websites. You can pretty much copy and paste your way to a functional lightning fast site.

This version contains the one CSS file you need in both minified and unminified versions "purecssframework.css"
#
Optional Files included: 
SASS version, 
Dark theme, 
Color theme, 
PCF carousel standalone CSS file (no dependences)
#
Have fun and learn how to use all the CSS and components here: http://www.purecssframework.com
#
Email me with any questions: lowell @ purecssframework.com
